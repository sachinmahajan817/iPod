import React from 'react';

class Game extends React.Component
{
    render()
    {
        return (
            <div className="screen-game">
                <h1>Games</h1>
                <div>
                    <i className="fas fa-gamepad"></i>
                </div>
            </div>
        );
    }
};

export default Game;