import React from 'react';

class Albums extends React.Component
{
    render()
    {
        return (
            <div className="albums-screen">
                <h1>
                    Albums
                </h1>
                <div>
                    <i className="fas fa-icons"></i>
                </div>
            </div>
        )

    }
}

export default Albums;