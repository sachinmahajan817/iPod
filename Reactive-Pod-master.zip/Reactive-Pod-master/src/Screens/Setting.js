import React from 'react';

class Setting extends React.Component
{
    render()
    {
        return (
            <div className="screen-setting">
                <h1>Settings</h1>
                <div>
                    <i className="fas fa-cogs"></i>
                </div>
            </div>
        );
    }
};

export default Setting;